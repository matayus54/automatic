<img src="./static/Jhoseb.svg"/>

### About me:

```js
import Front-End/Back-End Developer from 'Jhoseb';

class Bio extends Front-End/Back-End Developer {
  name     = 'Jose Moya';
  title    = 'Front-End Developer';
  location = 'La Mesa, CO';
}

class Skills extends Front-End/Back-End Developer {
  languages  = ['JavaScript', 'Python'];
  databases  = ['MySQL', 'MongoDB', 'PostgreSQL'];
  frameworks/librerias = ['React' 'Express'];
}
```

### GitHub Stats

[![GitHub Streak](https://github-readme-streak-stats.herokuapp.com/?user=Jhoseb29&theme=dark)](https://git.io/streak-stats)

<a href="https://github.com/ankitwarbhe">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Jhoseb29&theme=dark">
</a>



### Social Networks

[<img src="https://img.shields.io/badge/twitter-%231DA1F2.svg?&style=for-the-badge&logo=twitter&logoColor=white">](https://twitter.com/Jose_Jhoseb)
[<img src="https://img.shields.io/badge/linkedin-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white">](https://www.linkedin.com/in/jhoseb29/)
[<img src="https://img.shields.io/badge/discord-%231DA1F2.svg?&style=for-the-badge&logo=discord&logoColor=white">](https://discord.com/channels/379692226713878528)
[<img src="https://img.shields.io/badge/Portfolio-%23000000.svg?&style=for-the-badge">](https://jhoseb29.github.io/Jose-Moya/)


